import json
import hashlib
from typing import Dict, Any

# ============================================================================
# GLYPH GENERATOR CORE (Python)
# ============================================================================

def generate_glyph_svg(glyph_id: str, params: Dict[str, Any]) -> str:
    """
    Gera a string SVG para um glifo específico com base em seus parâmetros.
    Esta função implementa a lógica geométrica e topológica do NeoSigm Protocol.
    """
    
    # Configurações base
    size = 200
    stroke_width = 2.5
    
    # Inicia o SVG
    svg_content = f'<svg width="{size}" height="{size}" viewBox="0 0 {size} {size}" xmlns="http://www.w3.org/2000/svg">'
    
    # Implementação da lógica para os glifos AX-Core (Exemplos)
    if glyph_id == "GX-0001":
        # Identidade (Ponto Central)
        svg_content += f'<circle cx="100" cy="100" r="40" fill="none" stroke="black" stroke-width="{stroke_width}"/>'
        svg_content += f'<circle cx="100" cy="100" r="3" fill="black"/>'
    
    elif glyph_id == "GX-0002":
        # Relação (Dualidade)
        # Dois anéis (círculos) interconectados por um vetor (linha)
        r = 35
        dist = 80
        cx1, cx2 = 100 - dist/2, 100 + dist/2
        svg_content += f'<circle cx="{cx1}" cy="100" r="{r}" fill="none" stroke="black" stroke-width="{stroke_width}"/>'
        svg_content += f'<circle cx="{cx2}" cy="100" r="{r}" fill="none" stroke="black" stroke-width="{stroke_width}"/>'
        # Vetor de conexão (linha)
        svg_content += f'<line x1="{cx1 + r}" y1="100" x2="{cx2 - r}" y2="100" stroke="black" stroke-width="{stroke_width}"/>'

    elif glyph_id == "GX-0003":
        # Transformação (Vetor)
        # Linha com ponta de seta (marker)
        svg_content += '''
            <defs>
                <marker id="arrowhead" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
                    <polygon points="0 0, 10 3, 0 6" fill="black"/>
                </marker>
            </defs>
        '''
        svg_content += f'<line x1="40" y1="100" x2="160" y2="100" stroke="black" stroke-width="{stroke_width}" marker-end="url(#arrowhead)"/>'

    elif glyph_id == "GX-0004":
        # Ciclo (Anel)
        svg_content += f'<circle cx="100" cy="100" r="50" fill="none" stroke="black" stroke-width="{stroke_width}"/>'
        svg_content += f'<circle cx="100" cy="50" r="4" fill="black"/>'

    elif glyph_id == "GX-0005":
        # Fluxo (Espiral) - Simulação com curva Q
        svg_content += f'''
            <path d="M 100,100 
                     Q 130,70 160,100 
                     T 160,160 
                     T 100,160 
                     T 70,100 
                     T 100,40" 
                  fill="none" stroke="black" stroke-width="{stroke_width}"/>
        '''
    
    # ... Adicionar lógica para os demais glifos (GX-0006 a GX-0012) ...
    
    else:
        # Glifo Padrão (Fallback)
        svg_content += f'<text x="100" y="100" font-size="16" text-anchor="middle" fill="red">Glifo {glyph_id} não implementado</text>'
        
    svg_content += '</svg>'
    return svg_content.strip()

def generate_canonical_data(glyph_id: str, params: Dict[str, Any], svg_content: str) -> Dict[str, Any]:
    """
    Gera o JSON canônico (metadados) para o glifo.
    O hash é gerado a partir de uma representação canônica dos dados.
    """
    
    # Dados estáticos (Simulação de banco de dados/definição de protocolo)
    definitions = {
        "GX-0001": {"class": "CL-ID", "name": "Identidade", "description": "Ponto Central - Axioma fundamental de existência e singularidade", "primitives": ["P", "R"], "semantics": {"role": "identidade", "axiom": "Ponto"}},
        "GX-0002": {"class": "CL-REL", "name": "Relação", "description": "Dualidade - Conexão entre duas entidades distintas", "primitives": ["R", "R", "V"], "semantics": {"role": "relação", "axiom": "Vetor"}},
        "GX-0003": {"class": "CL-TRANS", "name": "Transformação", "description": "Vetor - Movimento direcional e mudança de estado", "primitives": ["V"], "semantics": {"role": "transformação", "axiom": "Vetor"}},
        "GX-0004": {"class": "CL-CYCLE", "name": "Ciclo", "description": "Anel - Continuidade e retroalimentação", "primitives": ["R"], "semantics": {"role": "ciclo", "axiom": "Anel"}},
        "GX-0005": {"class": "CL-FLOW", "name": "Fluxo", "description": "Espiral - Progressão e evolução contínua", "primitives": ["S"], "semantics": {"role": "fluxo", "axiom": "Espiral"}},
        # ... Adicionar definições para os demais glifos ...
    }
    
    definition = definitions.get(glyph_id, {"class": "CL-UNKNOWN", "name": "Desconhecido", "description": "Glifo não catalogado.", "primitives": [], "semantics": {"role": "desconhecido", "axiom": "N/A"}})

    # Monta o objeto de dados canônicos (sem o SVG)
    canonical_data = {
        "id": glyph_id,
        "class": definition["class"],
        "name": definition["name"],
        "description": definition["description"],
        "seed": "e5a9c3d2f7b1a8e4c6f9d2b5a8e1c4f7", # Seed de geração (fixo para v0.1)
        "primitives": definition["primitives"],
        "params": params,
        "semantics": definition["semantics"],
        "generated_at": "2025-10-26T12:00:00Z", # Data fixa para garantir hash consistente na v0.1
        "version": "0.1"
    }
    
    # 1. Serializa os dados canônicos (JSON sem espaços)
    canonical_string = json.dumps(canonical_data, separators=(',', ':'), sort_keys=True)
    
    # 2. Concatena com o SVG (forma canônica de representação)
    # O SVG é minificado e padronizado antes da concatenação.
    canonical_svg = svg_content.replace('\n', '').replace('\r', '').replace(' ', '')
    
    # String final para hashing: JSON_CANONICO + SVG_CANONICO
    hash_input = canonical_string + canonical_svg
    
    # 3. Gera o hash SHA-256
    canonical_hash = hashlib.sha256(hash_input.encode('utf-8')).hexdigest()
    
    # Adiciona o hash e o SVG ao objeto final
    canonical_data["hash"] = f"sha256:{canonical_hash}"
    canonical_data["svg"] = svg_content # Adiciona o SVG completo para facilitar o transporte

    return canonical_data

def get_glyph_data(glyph_id: str) -> Dict[str, Any]:
    """
    Função principal para obter todos os dados de um glifo.
    """
    
    # Parâmetros de exemplo (devem ser carregados de um banco de dados real)
    example_params = {
        "GX-0001": {"ratio": 1.0, "rot": 0, "scale": 1.0},
        "GX-0002": {"ratio": 1.618, "rot": 0, "scale": 1.0},
        "GX-0003": {"ratio": 1.0, "rot": 45, "scale": 1.0},
        "GX-0004": {"ratio": 1.0, "rot": 0, "scale": 1.0},
        "GX-0005": {"ratio": 1.618, "rot": 0, "scale": 1.0},
        # ...
    }
    
    params = example_params.get(glyph_id, {"ratio": 1.0, "rot": 0, "scale": 1.0})
    
    # 1. Gerar o SVG
    svg_content = generate_glyph_svg(glyph_id, params)
    
    # 2. Gerar os dados canônicos e o hash
    canonical_data = generate_canonical_data(glyph_id, params, svg_content)
    
    return canonical_data

# ============================================================================
# SERVIDOR FLASK (Para interagir com a interface web)
# ============================================================================

from flask import Flask, jsonify, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app) # Permite que o front-end (porta 8080) acesse o back-end (porta 5000)

@app.route('/generate/<glyph_id>', methods=['GET'])
def generate_glyph(glyph_id):
    """
    Endpoint para gerar e retornar os dados de um glifo.
    """
    try:
        data = get_glyph_data(glyph_id)
        if "CL-UNKNOWN" in data["class"]:
            return jsonify({"error": "Glifo não encontrado ou não implementado"}), 404
        
        # O SVG está incluído no JSON, o front-end irá extraí-lo.
        return jsonify(data), 200
    except Exception as e:
        app.logger.error(f"Erro ao gerar glifo {glyph_id}: {e}")
        return jsonify({"error": f"Erro interno do servidor: {str(e)}"}), 500

if __name__ == '__main__':
    # O servidor será executado na porta 5000
    app.run(host='0.0.0.0', port=5000)

