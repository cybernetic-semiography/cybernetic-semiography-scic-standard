import hashlib
import time
from typing import Dict, Any

# ============================================================================
# SIMULAÇÃO DE BLOCKCHAIN (NeoChain)
# ============================================================================

# Variáveis globais para simular o estado do contrato e do token
CONTRACT_ADDRESS = "0xNeoSigmProtocolContractAddress001"
TOKEN_COUNTER = 1000  # Começa em 1000 para simular tokens já emitidos
REGISTERED_GLYPHS = {}  # Hash -> Token Data

def generate_token_id(glyph_hash: str) -> int:
    """
    Gera um ID de token determinístico baseado no hash do glifo.
    Em um sistema real, isso seria o resultado da transação de minting.
    Aqui, usamos um hash simples para simular.
    """
    global TOKEN_COUNTER
    # Simula a emissão de um novo token
    TOKEN_COUNTER += 1
    return TOKEN_COUNTER

def register_glyph_on_chain(canonical_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Simula o registro do hash canônico do glifo em um contrato inteligente.
    Retorna os metadados do token (NFT).
    """
    
    glyph_hash = canonical_data.get("hash")
    
    if not glyph_hash:
        raise ValueError("Dados canônicos inválidos: hash ausente.")
        
    # Verifica se o glifo já foi registrado (imutabilidade)
    if glyph_hash in REGISTERED_GLYPHS:
        return REGISTERED_GLYPHS[glyph_hash]

    # 1. Simula a transação de "minting"
    token_id = generate_token_id(glyph_hash)
    
    # 2. Cria os metadados do token (NFT)
    token_metadata = {
        "token_id": token_id,
        "contract_address": CONTRACT_ADDRESS,
        "chain_id": "NeoChain-Testnet-v1",
        "timestamp": int(time.time()),
        "transaction_hash": hashlib.sha256(f"{glyph_hash}{token_id}{time.time()}".encode()).hexdigest(),
        "token_uri": f"https://neochain.io/token/{token_id}",
        "canonical_hash": glyph_hash
    }
    
    # 3. Registra e armazena (simulação)
    REGISTERED_GLYPHS[glyph_hash] = token_metadata
    
    return token_metadata

def get_token_metadata(glyph_hash: str) -> Dict[str, Any]:
    """
    Simula a consulta ao contrato inteligente para obter os metadados do token.
    """
    return REGISTERED_GLYPHS.get(glyph_hash, None)

if __name__ == '__main__':
    # Exemplo de uso
    test_data = {
        "id": "GX-0001",
        "hash": "sha256:fc9b9bdcaa2a2675d6ff97cddda19d7b44165e58dade55cfc880f20ab04ff1b0"
    }
    
    token = register_glyph_on_chain(test_data)
    print(f"Glifo registrado: {token}")
    
    # Tentativa de registrar o mesmo glifo (deve retornar o mesmo token)
    token_2 = register_glyph_on_chain(test_data)
    print(f"Glifo (re)registrado: {token_2}")
    
    assert token["token_id"] == token_2["token_id"]

